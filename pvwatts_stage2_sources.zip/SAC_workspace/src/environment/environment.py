"""Minimal adapter over the unmodified NSRDB/pvlib PVTrackingEnv.

Normalized actions stay [-1,1]^2. Degrees and rewards are computed by the
original environment, not approximated or transformed inside this adapter.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from importlib import metadata
from SAC_workspace.src.representation.representation import encode


class SACEnvironment:
    def __init__(self, env_kwargs: dict):
        from mbpo.env.pv_tracking import PVTrackingEnv
        if env_kwargs.get('observation_mode') != 'compact':
            raise ValueError('Must use compact mode for reference parity')
        self.env = PVTrackingEnv(**dict(env_kwargs))
        self.action_space = self.env.action_space
        self.observation_space = self.env.observation_space
        self.horizon = int(self.env.num_action_steps)
        if self.horizon != 117 or self.observation_space.shape != (6,) or self.action_space.shape != (2,):
            raise ValueError('Resolved MDP does not match compact 117-step reference')
        if not np.array_equal(np.asarray(self.action_space.low), np.array([-1, -1])) or not np.array_equal(np.asarray(self.action_space.high), np.array([1, 1])):
            raise ValueError('Unexpected reference action bounds')
        self.steps = 0
        # Record the effective PVTrackingEnv parameters, including defaults
        # omitted by the reference config. This catches upstream physics drift.
        source = self.env
        location = source.location
        def value(name):
            return getattr(source, name, None)
        def library_version(name):
            try:
                return metadata.version(name)
            except metadata.PackageNotFoundError:
                return None
        self.resolved_mdp = {
            'pvlib_version': library_version('pvlib'),
            'gym_version': library_version('gym'),
            'site_latitude': getattr(location, 'latitude', None),
            'site_longitude': getattr(location, 'longitude', None),
            'site_altitude': getattr(location, 'altitude', None),
            'tz': str(location.tz),
            'start_time': value('start_time'), 'periods': value('periods'),
            'freq': str(value('freq')),
            'weather_source': value('weather_source'),
            'area': value('area'), 'efficiency': value('efficiency'),
            'max_delta_tilt': value('max_delta_tilt'),
            'max_delta_azimuth': value('max_delta_azimuth'),
            'movement_penalty': value('movement_penalty'),
            'movement_cost_mode': value('movement_cost_mode'),
            'actuator_power_w': value('actuator_power_w'),
            'slew_rate_tilt_deg_s': value('slew_rate_tilt_deg_s'),
            'slew_rate_azimuth_deg_s': value('slew_rate_azimuth_deg_s'),
            'observation_mode': value('observation_mode'),
            'horizon': self.horizon,
        }

    def seed(self, seed: int) -> None:
        self.env.seed(seed)

    def reset(self, scenario_id: str | None = None) -> np.ndarray:
        self.steps = 0
        observation = encode(self.env.reset(scenario_id=scenario_id))
        if not np.isclose(observation[5], 1., atol=1e-6):
            raise RuntimeError('Finite-horizon observation must begin with tau=1')
        if str(self.env.location.tz).upper() != 'UTC':
            raise RuntimeError('Reference pvlib/NSRDB experiment must use UTC')
        return observation

    def step(self, action):
        a = np.asarray(action, dtype=np.float32)
        if a.shape != (2,) or not np.isfinite(a).all():
            raise ValueError(f'Action must be finite shape (2,), got {a}')
        if (np.abs(a) > 1.00001).any():
            raise ValueError('Policy generated action outside [-1,1]^2')
        obs, reward, done, info = self.env.step(np.clip(a, -1., 1.))
        self.steps += 1
        if self.steps > self.horizon or (self.steps == self.horizon) != bool(done):
            raise RuntimeError('Episode horizon or terminal signal disagrees with reference')
        observation = encode(obs)
        tau_expected = (self.horizon - self.steps) / self.horizon
        if not np.isclose(observation[5], tau_expected, atol=1e-6):
            raise RuntimeError('PVTrackingEnv compact tau feature does not match step count')
        if not np.isclose(reward, float(info['energy_kwh']) - float(info['movement_cost']), atol=1e-9):
            raise RuntimeError('Step reward differs from the reference net-energy definition')
        expected_time = self.env.times[self.steps]
        actual_time = pd.Timestamp(info['timestamp_utc_iso'])
        if (actual_time != expected_time or str(info['timezone']).upper() != 'UTC'
                or expected_time.utcoffset().total_seconds() != 0):
            raise RuntimeError(f'Solar step UTC timestamp mismatch: {actual_time!s} != {expected_time!s}')
        if (self.env.weather_source == 'nsrdb_multiyear'
                and (info['weather_resampling'] != 'none_native_5min'
                     or not np.isclose(info['control_interval_minutes'], 5., atol=1e-6))):
            raise RuntimeError('NSRDB scenario is not using the reference native 5-minute grid')
        return observation, float(reward), bool(done), info

    @property
    def unwrapped(self):
        return self.env

    def close(self):
        self.env.close()
